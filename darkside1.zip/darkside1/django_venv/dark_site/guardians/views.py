from django.shortcuts import render
from django.http import HttpResponse

def index(request):
    return HttpResponse('<h2>Guardians web site. Kasym chmo</h2>'
                        '<h4> Guardians of UK. Is one of the ...</h4>')
